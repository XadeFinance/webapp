import Component from './Component'
export default Component;