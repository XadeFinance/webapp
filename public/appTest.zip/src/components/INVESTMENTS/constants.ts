let contracts = [
    {
        id: '1',
        symbol: 'BTC',
        ticker: 'bitcoin.png',
        chart: 'BTC1!', 
        address: '0x'
    },
        {
        id: '2',
        symbol: 'TSLA',
        ticker: 'tesla.png',
        chart: 'TSLA',
        address: '0x'
    },
        {
        id: '3',
        symbol: 'Gold',
        ticker: 'gold.jpg',
        chart: 'GOLD',
        address: '0x'
    },
        {
        id: '4',
        symbol: 'ETH',
        ticker: 'ethereum.png',
        chart: 'ETH1!',
        address: '0x'
    },
        {
        id: '5',
        symbol: 'EURO',
        ticker: 'Euro.png',
        chart: 'Euro',
        address: '0x'
    }
]

export default contracts;