import React from 'react'
import './CarouselCard.css'
type Props = {}

const CarouselCard4 = (props: Props) => {
  return (

         <div className="box">
   
<br />
<br />
<a className="labelText"><br />Borrow against a variety of assets without any credit score on chain<br /><br /></a>
<br />
<img src="https://www.xade.finance/media/suitcase.png" className="carouselImg" />
<br />
<br />
<br />

  </div>

  )
}

export default CarouselCard4
