import React from 'react'
import './CarouselCard.css'
type Props = {}

const CarouselCard3 = (props: Props) => {
  return (

         <div className="box">   
<br />
<br />
<a className="labelText"><br />Beat Inflation with our stable savings account where you can earn upto 9.1% APY<br /><br /></a>
<br />
<img src="https://www.xade.finance/media/money.png" className="carouselImg" />

<br />
<br />
<br />

  </div>

  )
}

export default CarouselCard3
