import React from 'react'
import './CarouselCard.css'
type Props = {}

const CarouselCard1 = (props: Props) => {
  return (

         <div className="box">
 
<br />
<br />
<br />
<br />
<br />
<a className="labelText">          
<br />Send payments globally to mobile numbers with close to zero fees and instantly</a>
<br />
<br />
<img className="carouselImg" src="https://www.xade.finance/media/globe.png" />
<br />
<br />

  </div>

  )
}

export default CarouselCard1
