# Xade Webapp

## Team 

- Arav Budhiraja (@arav06)
- Andrew Alisa (@andrewalisa)
- Harsh Shaw (@harshshaw)
- Arnav Jhajharia (@Arnav-Jhajharia) 

## Tech Stack

- NodeJS
- ReactJS
- TypeScript
- Web3Auth
- MongoDB
- Python 
- Apache2

<b>The MWPRANT Stack</b>

***
