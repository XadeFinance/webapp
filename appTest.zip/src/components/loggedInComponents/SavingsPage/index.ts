import Component from './Component'

