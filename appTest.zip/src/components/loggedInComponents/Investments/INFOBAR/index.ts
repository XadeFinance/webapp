import infobar from './infobar'

export default infobar