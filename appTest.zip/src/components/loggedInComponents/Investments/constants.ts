let contracts = [
    {
        id: '1',
        symbol: 'BTC',
        ticker: 'bitcoin.png',
        chart: 'BITSTAMP:BTCUSD', 
        address: '0x'
    },
        {
        id: '2',
        symbol: 'TSLA',
        ticker: 'tesla.png',
        chart: 'TSLA',
        address: '0x'
    },
        {
        id: '3',
        symbol: 'XAU',
        ticker: 'gold.png',
        chart: 'FOREXCOM:XAUUSD',
        address: '0x'
    },
        {
        id: '4',
        symbol: 'ETH',
        ticker: 'ethereum.png',
        chart: 'BITSTAMP:ETHUSD',
        address: '0x'
    },
        {
        id: '5',
        symbol: 'EURO',
        ticker: 'Euro.png',
        chart: 'HUOBI:EUROCUSDC',
        address: '0x'
    }
]

export default contracts;