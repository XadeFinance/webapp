import Trade  from './Trade'

export default Trade