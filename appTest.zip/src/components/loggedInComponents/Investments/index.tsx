import React from 'react';
import MainSection from './MAINSECTION'
import InfoBar from './INFOBAR'

export default function Investments() {
    return (
        <>
        
            <InfoBar />



            <MainSection />
            
            
        </>
    )
}   