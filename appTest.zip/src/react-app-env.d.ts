/// <reference types="react-scripts" />

declare module 'react-qr-scanner';